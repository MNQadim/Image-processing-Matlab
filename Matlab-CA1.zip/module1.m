% Read in the video file
videoFileReader = vision.VideoFileReader('abbas.mp4');

% Create a foreground detector object
foregroundDetector = vision.ForegroundDetector('NumGaussians', 3, 'NumTrainingFrames', 50);

% Loop through each frame of the video
while ~isDone(videoFileReader)
    % Read the current frame
    frame = step(videoFileReader);
    
    % Apply background subtraction
    foregroundMask = step(foregroundDetector, frame);
    
    % Display the foreground mask
    imshow(foregroundMask);
end

% Release the video file reader
release(videoFileReader);
