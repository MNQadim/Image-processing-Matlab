clc
close all;
clear;
load TRAININGSET;
totalLetters=size(TRAIN,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%seconde phase

% getting the image
[file,path]=uigetfile({'*.jpg;*.bmp;*.png;*.tif'},'Choose an image');
s=[path,file];
image=imread(s);

% converting to gray
gray_image = rgb2gray(image);

% Dilate the image to make the edges thicker
% SE = strel('square', 4);
% dilated_image = imdilate(gray_image, SE);

dilated_image = gray_image;

% removing noises using median filter
filtered_image = medfilt2(dilated_image);
figure, imshow (filtered_image);

% changing to black and white
threshold = 128; % threshold value
filtered_img = filtered_image > threshold;

%figure, imshow (filtered_img);
%title('Processed Image');

% Detecting edges
edge_image = edge(filtered_img, 'Canny');

%figure, imshow (edge_image);

% giving max and min of acceptable retio
min_ratio = 3.3;
max_ratio = 4.5;

% measuring properties of regions
props = regionprops(edge_image, 'BoundingBox', 'Area');

% filtering the rectangles by max and min ratio
aspect_ratios = [props.BoundingBox];
aspect_ratios = aspect_ratios(3:4:end) ./ aspect_ratios(4:4:end);
valid_regions = (aspect_ratios >= min_ratio) & (aspect_ratios <= max_ratio) & ([props.Area] > 0);

% counting transitions from white in a certain region
num_transitions = zeros(1, length(props));
for k = find(valid_regions)
    region = edge_image(round(props(k).BoundingBox(2)):round(props(k).BoundingBox(2)+props(k).BoundingBox(4)), ...
                        round(props(k).BoundingBox(1)):round(props(k).BoundingBox(1)+props(k).BoundingBox(3)));
    num_transitions(k) = sum(abs(diff(region(:))))/2;
end

% rectangle with the most transitions
[max_transitions, max_index] = max(num_transitions);

% placing the rectangle in original photo and 
% showing rectangles with most transitions

%figure;imshow(image);title ('avvalie')
hold on;
for k = find(valid_regions)
    if k == max_index
        rectangle('Position', props(k).BoundingBox, 'EdgeColor', 'red', 'LineWidth', 2);
    else
        rectangle('Position', props(k).BoundingBox, 'EdgeColor', 'green', 'LineWidth', 2);
    end
end
title(sprintf('Rectangle with the most transitions (%d)', max_transitions));

% croping the plate from original photo
max_rect_coords = props(max_index).BoundingBox;
cropped_image = imcrop(image, max_rect_coords);

img_asli = cropped_image;

% converting the image to grayscale
gray_image = rgb2gray(img_asli);

dilated_image = gray_image;

% removing noise using threshold and median filter
filtered_image = medfilt2(dilated_image);
threshold = 128;
filtered_img = filtered_image > threshold; 

figure, imshow(filtered_img);title('processed cropped image final');
picture = ~filtered_img;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Third phase!

%figure;subplot(1,2,1);imshow(picture);
picture=imresize(picture,[350 400]);
subplot(1,2,2);
imshow(picture);
 
% Removing the small objects and background
figure
% removes all connected components (objects) that have fewer than 800 pixels from the binary image BW
 picture = bwareaopen(picture,800); 
 subplot(1,3,1)
 imshow(picture)
% removes all connected components (objects) that have fewer than 8000 pixels from the binary image BW
background=bwareaopen(picture,8000); subplot(1,3,2)
 imshow(background)
picture2=picture-background;
 subplot(1,3,3)
 imshow(picture2)

%Labeling connected components

%figure;imshow(picture2)
[L,Ne]=bwlabel(picture2);
propied=regionprops(L,'BoundingBox');
hold on
for n=1:size(propied,1)
    
    rectangle('Position',propied(n).BoundingBox,'EdgeColor','g','LineWidth',2)

end
hold off

% Decision Making
if (Ne==8 || Ne==9)
    figure
final_output=[];
t=[];
for n=1:Ne
    [r,c] = find(L==n);
    Y=picture2(min(r):max(r),min(c):max(c));
    imshow(Y)
    Y=imresize(Y,[400,350]);
    imshow(Y)
    pause(0.2)
    
    
    ro=zeros(1,totalLetters);
    for k=1:totalLetters   
        ro(k)=corr2(TRAIN{1,k},Y);
    end
    if n==7
        saeed=1;
    end
     ro=abs(ro);
    [MAXRO,pos]=max(ro);
    if (MAXRO > 0.45)
        out=cell2mat(TRAIN(2,pos));       
        final_output=[final_output out];
    end
end
end
   
  % there might be some errors in this case
    if (Ne>9 || Ne<8)
    figure
    final_output=[];
    t=[];
for n=1:Ne
         [r,c] = find(L==n);
    Y=picture2(min(r):max(r),min(c):max(c));
    imshow(Y)
    Y=imresize(Y,[400,350]);
    imshow(Y)
    pause(0.2)
    
    
    ro=zeros(1,totalLetters);
    for k=1:totalLetters   
        ro(k)=corr2(TRAIN{1,k},Y);
    end
    if n==7
        saeed=1;
    end
    ro=abs(ro);
    [MAXRO,pos]=max(ro);
    if MAXRO > 0.45
        out=cell2mat(TRAIN(2,pos));       
        final_output=[final_output out];
    end
end
    end

% Printing the plate
file = fopen('number_Plate.txt', 'wt');
fprintf(file,'%s\n',final_output);
fclose(file);
winopen('number_Plate.txt')